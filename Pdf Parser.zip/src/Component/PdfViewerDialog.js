import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField } from '@material-ui/core';

function PdfViewerDialog({ open, onClose }) {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(URL.createObjectURL(selectedFile));
    }
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>PDF Viewer</DialogTitle>
      <DialogContent>
        <input type="file" accept=".pdf" onChange={handleFileChange} />
        {file && <embed src={file} width="100%" height="500px" />}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}

export default PdfViewerDialog;
