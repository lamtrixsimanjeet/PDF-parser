import React from 'react'

function Footer() {
  return (
    <div style={{textAlign: "center"}}>
       <p>Privacy Policy | © 2023 HighRadius Corporation. All rights reserved.</p>
    </div>
  )
}

export default Footer