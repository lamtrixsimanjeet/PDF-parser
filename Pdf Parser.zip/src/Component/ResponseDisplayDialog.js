import React from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Paper } from '@material-ui/core';

function ResponseDisplayDialog({ open, onClose, response }) {
  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Server Response</DialogTitle>
      <DialogContent>
        <Paper elevation={3} style={{ padding: '16px' }}>
          <pre>{JSON.stringify(response, null, 2)}</pre>
        </Paper>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}

export default ResponseDisplayDialog;
