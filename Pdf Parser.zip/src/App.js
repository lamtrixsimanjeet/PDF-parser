import React, { useState } from 'react';
import './App.css';
import axios from 'axios';

function App() {
  const [pdfContent, setPdfContent] = useState(null);
  const [textInput, setTextInput] = useState('');
  const [responseContent, setResponseContent] = useState(null);

  const handlePdfUpload = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setPdfContent(URL.createObjectURL(selectedFile));
    }
  };

  const handleRemovePdf = () => {
    setPdfContent(null);
  };

  const handleTextSubmit = (text) => {
    const flaskEndpoint = 'http://localhost:5000/predict'; // Replace with your actual Flask API URL

    // Make a POST request to send user input
    axios.post(flaskEndpoint, { text: text })
      .then((response) => {
        // Handle the response data
        setTimeout(() => {
          setResponseContent(response.data);
        }, 1000);
      })
      .catch((error) => {
        console.error('Error sending data to Flask:', error);
      });
    
  };
  const handleClearText = () => {
    setTextInput('');
  };

  const handleClearResponse = () => {
    setResponseContent(null);
  };
  return (
    <div className="container">
      {/* PDF Viewer Window */}
      <div className="window">
        <div className="window-title">PDF Viewer</div>
        <div className="window-content">
          {pdfContent ? (
            /* Render PDF content here */
            <>
              <embed src={pdfContent} width="100%" height="100%" />
              <button onClick={handleRemovePdf}>Remove PDF</button>
            </>
          ) : (
            <>
              <input
                type="file"
                accept=".pdf"
                onChange={handlePdfUpload}
                style={{ marginBottom: '10px' }}
              />
            </>
          )}
        </div>
      </div>

      {/* Text Input Window */}
      <div className="window">
        <div className="window-title">Text Input</div>
        <div className="window-content" style={{ height: '100%' }}>
          <textarea
            rows="10"
            cols="30"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            style={{  width: '98%',height: '95%' }}
          />
          <button onClick={() => handleTextSubmit(textInput)}>Submit Text</button>
          <button onClick={handleClearText}>Clear Text</button>
        </div>
      </div>

      {/* Response Display Window */}
      <div className="window" style={{ width: '300px', height: '570px' }}>
        <div className="window-title">Response Display</div>
        <div className="window-content">
          <pre>{responseContent}</pre>
        </div>
        <button onClick={handleClearResponse}>Clear Response</button>
      </div>
    </div>
  );
}

export default App;
