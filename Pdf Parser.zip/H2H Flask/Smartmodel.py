import os
import openai


def predict(df):
    
    openai.api_key = "Give your API KEY"

    response = openai.ChatCompletion.create(
      model="gpt-3.5-turbo-16k",
      messages=[
        {
          "role": "user",
          "content": df
        }
      ],
      temperature=0,
      max_tokens=4000,
      top_p=0,
      frequency_penalty=0,
      presence_penalty=0
    )
  

    return response["choices"][0]["message"]["content"]